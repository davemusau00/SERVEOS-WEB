# ServOS documentation

ServOS currently runs one installed authoritative terminal. The accepted expansion targets shared desktop/Vercel operations for one business; it is not yet enabled.

- [Accepted expansion and phase gates](EXPANSION_PLAN.md)
- [Source audit](EXPANSION_AUDIT.md)
- [Synchronization, identity and data contracts](EXPANSION_CONTRACTS.md)
- [Domain workflows](EXPANSION_WORKFLOWS.md)
- [Receipt specification](RECEIPT_SPEC.md)
- [Expansion acceptance matrix](EXPANSION_ACCEPTANCE.md)
- [Implementation handoff and remaining boundaries](EXPANSION_HANDOFF.md)

- [Current release state](CURRENT_RELEASE_STATE.md)
- [UX and Guidance delivery plan](UX_GUIDANCE_DELIVERY_PLAN.md)
- [Feature coverage](FEATURE_COVERAGE_MATRIX.md)
- [Implementation plan](IMPLEMENTATION_PLAN.md)
- [Gap analysis and roadmap](GAP_ANALYSIS_AND_ROADMAP.md)
- [Architecture](SYSTEM_ARCHITECTURE.md)
- [RBAC and permissions](RBAC_AND_PERMISSIONS.md)
- [Onboarding and setup](ONBOARDING_AND_SETUP.md)
- [Terminal operator accounts and one-time device pairing](TERMINAL_OPERATOR_AUTH_SETUP.md)
- [Operational workflows](MODULE_WORKFLOWS.md)
- [Data dictionary](DATA_DICTIONARY.md)
- [Deployment runbook](DEPLOYMENT_RUNBOOK.md)
- [Customer tabs and credit](CUSTOMER_CREDIT.md)
- [Existing-terminal 0.2.0 upgrade](EXISTING_TERMINAL_UPGRADE.md)
- [0.2.0 release acceptance](RELEASE_0.2_ACCEPTANCE.md)
- [Completion ledger](COMPLETION_LEDGER.md)
- [Test evidence](TEST_EVIDENCE.md)
- [Bar production acceptance](BAR_PRODUCTION_ACCEPTANCE.md)
- [Changelog](CHANGELOG.md)
- `user-guide/`: source of truth for the offline in-app Help Center.
- `generated/UI_INTERACTION_INVENTORY.json`: compact static inventory summary, not acceptance evidence; the full inventory is emitted as the CI `ui-audit` artifact.
